package com.example.youthhouseapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.File;

public class AccountManagerActivity extends AppCompatActivity {

    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_manager);
        //Get the Intent that started this activity
        Intent intent = getIntent();
        context = this;
        setData();
    }

    //Prints account info into EditText fields in account manager.
    public void setData(){
        System.out.println("Going to read accountdata.csv");
        FileManager.readAccountFile(context);
        for (Object o : FileManager.al) {
            System.out.println("Account information: ");
            Account e = (Account) o;
            String name = e.getName();
            String phoneNumber = e.getPhoneNumber();
            String email = e.getEmail();
            EditText aName = (EditText)findViewById(R.id.editTextAccountName);
            EditText aNumber = (EditText)findViewById(R.id.editTextAccountNumber);
            EditText aEmail = (EditText)findViewById(R.id.editTextAccountEmail);
            aName.setText(name);
            aNumber.setText(phoneNumber);
            aEmail.setText(email);
        }
    }

    //Updates account information and saves it into a file
    public void updateData(View v){
        EditText aName = (EditText)findViewById(R.id.editTextAccountName);
        EditText aNumber = (EditText)findViewById(R.id.editTextAccountNumber);
        EditText aEmail = (EditText)findViewById(R.id.editTextAccountEmail);
        for (Object o : FileManager.al) {
            Account a = (Account) o;
            a.setName(aName.getText().toString());
            a.setPhoneNumber(aNumber.getText().toString());
            a.setEmail(aEmail.getText().toString());

            CharSequence text = "Account has been updated.";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
        FileManager.writeAccountFile(context);
    }
}
