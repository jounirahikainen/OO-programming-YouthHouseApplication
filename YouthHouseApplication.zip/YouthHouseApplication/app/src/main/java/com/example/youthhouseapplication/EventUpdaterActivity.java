package com.example.youthhouseapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

public class EventUpdaterActivity extends AppCompatActivity {

    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_updater);

        //Get the Intent that started this activity
        Intent intent = getIntent();
        context = this;
    }

    //Find specified event by name && date
    public void findEvent(View v){
        EditText name = (EditText)findViewById(R.id.editTextFindName);
        EditText date = (EditText)findViewById(R.id.editTextFindDate);

        for (Object o : FileManager.el) {
            System.out.println("Finding event");
            Event e = (Event) o;

            if (name.getText().toString().equals(e.getName()) && date.getText().toString().equals(e.getDate())){
                System.out.println("Found event with information: " + name.getText().toString() + " and " + date.getText().toString());
                setContent(e.getName(),e.getDate(),e.getLocation(),e.getAgeGroup(),e.getDescription(),e.getPopulation(),e.getFeedback(),e.getActivity());
                break;
            }
        }
    }

    //Updates the information fields when the correct event has been found
    private void setContent(String pName, String pDate, String pLocation, String pAgeGroup, String pDescription, String pPopulation, String pFeedback, String pActivity){
        EditText name = (EditText)findViewById(R.id.editTextUpdateName);
        EditText date = (EditText)findViewById(R.id.editTextUpdateDate);
        EditText location = (EditText)findViewById(R.id.editTextUpdateLocation);
        EditText ageGroup = (EditText)findViewById(R.id.editTextUpdateAgeGroup);
        EditText description = (EditText)findViewById(R.id.editTextUpdateDescription);
        EditText population = (EditText)findViewById(R.id.editTextUpdatePopulation);
        EditText feedback = (EditText)findViewById(R.id.editTextUpdateFeedback);
        Switch activitySwitch = (Switch)findViewById(R.id.switchUpdateEventActivity);

        if (pActivity.equals("Yes")){
            activitySwitch.setChecked(true);
        } else if(pActivity.equals("No")){
            activitySwitch.setChecked(false);
        }

        System.out.println("Setting texts");
        name.setText(pName);
        date.setText(pDate);
        location.setText(pLocation);
        ageGroup.setText(pAgeGroup);
        description.setText(pDescription);
        population.setText(pPopulation);
        feedback.setText(pFeedback);

    }

    //Updates all fields in an event.
    public void updateEvent(View v){
        EditText fName = (EditText)findViewById(R.id.editTextFindName);
        EditText fDate = (EditText)findViewById(R.id.editTextFindDate);

        EditText name = (EditText)findViewById(R.id.editTextUpdateName);
        EditText date = (EditText)findViewById(R.id.editTextUpdateDate);
        EditText location = (EditText)findViewById(R.id.editTextUpdateLocation);
        EditText ageGroup = (EditText)findViewById(R.id.editTextUpdateAgeGroup);
        EditText description = (EditText)findViewById(R.id.editTextUpdateDescription);
        EditText population = (EditText)findViewById(R.id.editTextUpdatePopulation);
        EditText feedback = (EditText)findViewById(R.id.editTextUpdateFeedback);

        String activity = "Not set.";
        // initiate a Switch
        Switch activitySwitch = (Switch) findViewById(R.id.switchUpdateEventActivity);
        // check current state of a Switch (true or false).
        if (activitySwitch.isChecked()){
            activity = "Yes";
        } else {
            activity = "No";
        }

        for (Object o : FileManager.el) {
            Event e = (Event) o;
            //Finding the correct event and applying changes to it
            if (fName.getText().toString().equals(e.getName()) && fDate.getText().toString().equals(e.getDate())){
                e.setName(name.getText().toString());
                e.setDate(date.getText().toString());
                e.setLocation(location.getText().toString());
                e.setAgeGroup(ageGroup.getText().toString());
                e.setDescription(description.getText().toString());
                e.setPopulation(population.getText().toString());
                e.setFeedback(feedback.getText().toString());
                e.setActivity(activity);

                CharSequence text = "Event has been updated.";
                int duration = Toast.LENGTH_SHORT;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();

                System.out.println("Event updated");
                break;
            }
        }
        FileManager.writeToSaveFile(context);
    }
}
