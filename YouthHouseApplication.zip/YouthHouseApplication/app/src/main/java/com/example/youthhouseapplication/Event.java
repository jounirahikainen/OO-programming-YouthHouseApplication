package com.example.youthhouseapplication;

public class Event {

    private String name;
    private String date;
    private String location;
    private String ageGroup;
    private String description;
    private String population;
    private String feedback;
    private String activity;

    Event(String name, String date, String location, String ageGroup, String description, String population, String feedback, String activity
    ){
        //this.id = id;
        this.name = name;
        this.date = date;
        this.location = location;
        this.ageGroup = ageGroup;
        this.description = description;
        this.population = population;
        this.feedback = feedback;
        this.activity = activity;
    }

    public String getName() {return name;}

    public void setName(String name) {
        this.name = name;
    }

    String getDate() {
        return date;
    }

    void setDate(String date) {
        this.date = date;
    }

    String getLocation() {
        return location;
    }

    void setLocation(String location) {
        this.location = location;
    }

    String getAgeGroup() {
        return ageGroup;
    }

    void setAgeGroup(String ageGroup) {
        this.ageGroup = ageGroup;
    }

    String getDescription() {
        return description;
    }

    void setDescription(String description) {
        this.description = description;
    }

    String getPopulation() {
        return population;
    }

    void setPopulation(String population) {
        this.population = population;
    }

    String getFeedback() {
        return feedback;
    }

    void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    String getActivity() {return activity;}

    void setActivity(String activity) {this.activity = activity;}
}
