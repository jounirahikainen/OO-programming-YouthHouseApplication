package com.example.youthhouseapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class EventManagerActivity extends AppCompatActivity {

    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_manager);
        //Get the Intent that started this activity
        Intent intent = getIntent();
        context = this;
    }

    //Called when user clicks "Move to event list button"
    public void moveToEventList(View v){
        //Reads events and updates arraylist before moving into new activity
        FileManager.readSaveFile(context);
        Intent intent = new Intent(this, EventListingActivity.class);
        startActivity(intent);
    }

    //Called when user clicks "Update events button"
    public void moveToEventUpdater(View v){
        Intent intent = new Intent(this, EventUpdaterActivity.class);
        startActivity(intent);
    }

    //Called when user clicks "Create event button"
    public void moveToCreateEvent(View v){
        Intent intent = new Intent(this, CreateEventActivity.class);
        startActivity(intent);
    }
}
