package com.example.youthhouseapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

//Created by Jouni Rahikainen
//Jouni.Rahikainen@student.lut.fi
public class MainActivity extends AppCompatActivity {

    Context context = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = this;
        //Reading both event and account files so that those files won't be erased if creating/updating either.
        FileManager.readSaveFile(context);
        FileManager.readAccountFile(context);
    }

    public void moveToEventManagerActivity(View v){
        Intent intent = new Intent(this, EventManagerActivity.class);
        startActivity(intent);
    }

    public void moveToAccountSettings(View v){
        Intent intent = new Intent(this, AccountManagerActivity.class);
        startActivity(intent);
    }
}
