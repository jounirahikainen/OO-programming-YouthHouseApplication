package com.example.youthhouseapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class EventListingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Setting content views and listViews to correct layouts
        setContentView(R.layout.activity_event_listing);
        ListView listView = (ListView) findViewById(R.id.ListViewEvent);

        //Get the Intent that started this activity
        Intent intent = getIntent();

        //Calling custom adapter for listView
        EventListAdapter adapter = new EventListAdapter(this, R.layout.custom_event_list_adapter, FileManager.el);
        listView.setAdapter(adapter);
    }
}
