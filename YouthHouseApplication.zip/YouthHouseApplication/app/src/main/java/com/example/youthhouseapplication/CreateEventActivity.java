package com.example.youthhouseapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;


public class CreateEventActivity extends AppCompatActivity {

    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_event);

        //Get the Intent that started this activity
        Intent intent = getIntent();
        context = this;
    }

    public void createEvent(View v){
        EditText name = (EditText) findViewById(R.id.editEventName);
        EditText date = (EditText) findViewById(R.id.editEventDate);
        EditText location = (EditText) findViewById(R.id.editEventLocation);
        EditText ageGroup = (EditText) findViewById(R.id.editEventAgegroup);
        EditText description = (EditText) findViewById(R.id.editEventDescription);
        EditText population = (EditText) findViewById(R.id.editEventPopulation);
        EditText feedback = (EditText) findViewById(R.id.editEventFeedback);
        String activity = "Not set.";
        // initiate a Switch
        Switch activitySwitch = (Switch) findViewById(R.id.switchEventActivity);
        // check current state of a Switch (true or false).
        if (activitySwitch.isChecked()){
            activity = "Yes";
        } else {
            activity = "No";
        }

        //Creates new instance of element and save it into singleton list.
        Event e = new Event(name.getText().toString(), date.getText().toString(),
                location.getText().toString(),ageGroup.getText().toString(),
                description.getText().toString(),population.getText().toString(),
                feedback.getText().toString(),activity);

        FileManager.el.add(e);
        //Saving the event into a file.
        FileManager.writeToSaveFile(context);

        //Toast so that users know when an event has been created.
        CharSequence text = "Event has been created.";
        int duration = Toast.LENGTH_SHORT;
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();

        System.out.println("Created event.");

    }

}
