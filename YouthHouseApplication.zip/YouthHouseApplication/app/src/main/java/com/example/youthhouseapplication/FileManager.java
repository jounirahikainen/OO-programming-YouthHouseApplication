package com.example.youthhouseapplication;

import android.content.Context;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;


public class FileManager {

    //Setting up the class as a singleton
    private static FileManager fms = null;

    public static FileManager getInstance()
    {
        if (fms == null)
            fms = new FileManager();

        return fms;
    }

    //ArrayList that is used to display information. Public on purpose.
    static ArrayList el = new ArrayList();

    //ArrayList used for account information.
    static ArrayList al = new ArrayList();

    //Reads save file that contains account information
    static void readAccountFile(Context context){
        //Clearing ArrayList so there is no duplicates.
        al.clear();
        try{
            InputStream ins = context.openFileInput("accountdata.csv");
            BufferedReader br = new BufferedReader(new InputStreamReader(ins));
            String s = "";
            while ((s = br.readLine()) != null){
                String[] tokens = s.split(";");
                Account listAccount = new Account(tokens[0],tokens[1],tokens[2]);
                al.add(listAccount);
                System.out.println("Read accountdata.csv with information: " + s);
            }
            ins.close();
        } catch (IOException e){
            Log.e("IOException", "Error in reading account data.");
        }
    }

    //Writes to save file that contains account information
    static void writeAccountFile(Context context){
        String s;
        try {
            OutputStreamWriter ows = new OutputStreamWriter(context.openFileOutput("accountdata.csv", Context.MODE_PRIVATE));
            System.out.println(el.size());
            for (Object o : FileManager.al) {
                System.out.println("New iteration in account file writer");
                Account e = (Account) o;
                String name = e.getName();
                String phoneNumber = e.getPhoneNumber();
                String email = e.getEmail();
                s = (name + ";" + phoneNumber + ";" + email + "\n");
                ows.write(s);
            }
            ows.close();
            System.out.println("File has been written successfully.");
        } catch (IOException e) {
            Log.e("IOException", "Error in feed. Append.");
        }
    }

    //Reads save file that contains event information
    static void readSaveFile(Context context) {
        //Clearing needed so there's no duplicate objects
        el.clear();
        try {
            InputStream ins = context.openFileInput("eventdata.csv");
            BufferedReader br = new BufferedReader(new InputStreamReader(ins));
            String s = "";
            while ((s = br.readLine()) != null) {
                String[] tokens = s.split(";");
                Event listEvent = new Event(tokens[0],tokens[1],tokens[2],tokens[3],tokens[4],tokens[5],tokens[6],tokens[7]);
                el.add(listEvent);
                System.out.println("Iteration: " + el.size());
                System.out.println(s);
            }
            ins.close();
        } catch (IOException e) {
            Log.e("IOException", "Error in reading events data.");
        } finally {
            System.out.println("Data file eventdata.csv has been read.");
        }
    }

    //Writes to save file that contains event information
    static void writeToSaveFile(Context context){
        String s;
        //Use this version of s to flush the saveFile with following information. You have to comment out the latter definition.
        //s = "Nuorisotapahtuma 2;22.04.2020;Skinnarila 2;13-14;Eristaytyminen 2;10;Test 2;no\n";
        System.out.println(el.size());
        try {
            OutputStreamWriter ows = new OutputStreamWriter(context.openFileOutput("eventdata.csv", Context.MODE_PRIVATE));
            for (Object o : FileManager.el) {
                System.out.println("New iteration in filewriter");
                Event e = (Event) o;
                String name = e.getName();
                String date = e.getDate();
                String location = e.getLocation();
                String ageGroup = e.getAgeGroup();
                String description = e.getDescription();
                String population = e.getPopulation();
                String feedback = e.getFeedback();
                String activity = e.getActivity();
                s = (name + ";" + date + ";" + location  + ";" + ageGroup  + ";" + description  + ";" + population  + ";" + feedback + ";" + activity +"\n");
                ows.write(s);
            }
            ows.close();
            System.out.println("File has been written successfully.");
        } catch (IOException e) {
            Log.e("IOException", "Error in feed. Append.");
        }
    }
}
