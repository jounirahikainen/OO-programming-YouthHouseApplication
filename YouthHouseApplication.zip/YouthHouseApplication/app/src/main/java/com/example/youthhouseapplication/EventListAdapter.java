package com.example.youthhouseapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.ArrayList;


public class EventListAdapter extends ArrayAdapter<Event> {

    private static final String TAG = "EventListAdapter";

    private Context context;
    int resource;

    EventListAdapter(Context context, int resource, ArrayList<Event> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        String name = getItem(position).getName();
        String date = getItem(position).getDate();
        String location = getItem(position).getLocation();
        String AgeGroup = getItem(position).getAgeGroup();
        String Population = getItem(position).getPopulation();
        String Description = getItem(position).getDescription();
        String Feedback = getItem(position).getFeedback();
        String Activity = getItem(position).getActivity();

        LayoutInflater inflater = LayoutInflater.from(context);
        convertView = inflater.inflate(resource, parent, false);

        TextView EName = (TextView) convertView.findViewById(R.id.textView1);
        TextView ELocation = (TextView) convertView.findViewById(R.id.textView2);
        TextView EDate = (TextView) convertView.findViewById(R.id.textView3);
        TextView EAgeGroup = (TextView) convertView.findViewById(R.id.textView4);
        TextView EPopulation = (TextView) convertView.findViewById(R.id.textView5);
        TextView EDescription = (TextView) convertView.findViewById(R.id.textView6);
        TextView EFeedback = (TextView) convertView.findViewById(R.id.textView7);
        TextView EActivity = (TextView) convertView.findViewById(R.id.textView8);

        EName.setText(name);
        ELocation.setText(location);
        EDate.setText(date);
        EAgeGroup.setText(AgeGroup);
        EPopulation.setText(Population);
        EDescription.setText(Description);
        EFeedback.setText(Feedback);
        EActivity.setText(Activity);

        return convertView;
    }



}
